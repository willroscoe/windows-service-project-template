﻿namespace $safeprojectname$
{
    public enum LogType
    {
        BeginEnd,
        Standard,
        Minor,
        Error,
        Highlight,
        Alert
    }
}
